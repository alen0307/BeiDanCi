import os
import json
import re
# ====== 配置 ======
INPUT_WORD_FILE = "考研.txt"      # 原始单词列表（每行一个单词）
DICT_CHUNKS_DIR = "dict_chunks"    # 词典分片目录
OUTPUT_JSON_FILE = "考研超简版.json"    # 输出 JSON
# =================

def load_dict_chunks():
    """加载所有词典分片"""
    dict_data = {}
    if not os.path.exists(DICT_CHUNKS_DIR):
        raise FileNotFoundError(f"词典分片目录 {DICT_CHUNKS_DIR} 不存在")
    
    for filename in os.listdir(DICT_CHUNKS_DIR):
        if filename.startswith("dict_") and filename.endswith(".json"):
            with open(os.path.join(DICT_CHUNKS_DIR, filename), "r", encoding="utf-8") as f:
                chunk = json.load(f)
                dict_data.update(chunk)
    print(f"✅ 加载 {len(dict_data)} 个词典条目")
    return dict_data

def extract_phonetic(html_content):
    """从HTML中提取音标，支持 <span class="phone"> 和 金莎 <font color=red> 格式"""
    import re
    
    # 方案1: 匹配 <span class="phone">...</span>
    span_match = re.search(r'<span[^>]*class\s*=\s*["\']?phone["\']?[^>]*>([^<]+)</span>', html_content, re.IGNORECASE)
    if span_match:
        return span_match.group(1).strip()
    
    # 方案2: 匹配金莎词典的 <font color=red> 格式（兼容旧词典）
    font_match = re.search(r'<font[^>]*color\s*=\s*["\']?red["\']?[^>]*>([^<]+)</font>', html_content, re.IGNORECASE)
    if font_match:
        return font_match.group(1).strip()
    
    # 未找到
    return ""

def main():
    # 1. 加载词典
    dict_data = load_dict_chunks()
    
    # 2. 读取单词列表（每行一个单词）
    if not os.path.exists(INPUT_WORD_FILE):
        raise FileNotFoundError(f"单词列表 {INPUT_WORD_FILE} 不存在")
    
    vocab = []
    not_found = []
    
    with open(INPUT_WORD_FILE, "r", encoding="utf-8") as f:
        for line in f:
            word = line.split('\t', 1)[0].strip()
            wordmean=line.split('\t', 1)[1].strip()
            if not word:
                continue
                
            # 在词典中查找（不区分大小写）
            dict_key = word.lower()
            html_content = dict_data.get(dict_key)
            
            if html_content:
                phone = extract_phonetic(html_content)
                shiyi=re.sub(r'<span class="return-phrase[^>]*>.*?</span>',"",html_content)
  
                shiyi = re.sub(r'<span class="phone[^>]*>.*?</span>', '', shiyi, flags=re.DOTALL)
                shiyi = re.sub(r'\\n', '', shiyi, flags=re.DOTALL)
                vocab.append({
                    "word": word,
                    "phone": phone,
                    "html": wordmean  # 保留完整HTML
                })
                print(f"✅ {word}")
            else:
                # 未找到：保留单词，音标和HTML为空
                vocab.append({
                    "word": word,
                    "phone": "",
                    "html": wordmean
                })
                not_found.append(word)
                print(f"⚠️  {word}（未找到）")
    
    # 3. 保存为 JSON
    with open(OUTPUT_JSON_FILE, "w", encoding="utf-8") as f:
        json.dump(vocab, f, ensure_ascii=False, indent=2)
    
    print(f"\n🎉 生成完成！")
    print(f"   输出文件: {OUTPUT_JSON_FILE}")
    print(f"   总词数: {len(vocab)}")
    print(f"   未找到: {len(not_found)} 个")

if __name__ == "__main__":
    main()
